package com.example.assignment2_v2;

import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

public class FirstFragment extends Fragment {

    private DatabaseHelper databaseHelper;
    private ListView listView;
    private SimpleCursorAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //inflate the layout for fragment and get the ListView
        View rootView = inflater.inflate(R.layout.fragment_first, container, false);
        listView = (ListView) rootView.findViewById(R.id.listView);
        databaseHelper = new DatabaseHelper(getActivity());
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //find views by id
        EditText addressInput = view.findViewById(R.id.addressInput);
        EditText latitudeInput = view.findViewById(R.id.latitudeInput);
        EditText longitudeInput = view.findViewById(R.id.longitudeInput);
        Button addButton = view.findViewById(R.id.addButton);

        //set up the button for adding a location
        addButton.setOnClickListener(v -> {
            String address = addressInput.getText().toString();

            //return the values that the user inputted
            double latitude = Double.parseDouble(latitudeInput.getText().toString());
            double longitude = Double.parseDouble(longitudeInput.getText().toString());

            //add location to the database
            long id = databaseHelper.addLocation(address, latitude, longitude);
            if (id != -1)
                {
                    Toast.makeText(getContext(), "Location added", Toast.LENGTH_SHORT).show();
                    refreshList();
                }
            else
                {
                    Toast.makeText(getContext(), "could not add location", Toast.LENGTH_SHORT).show();
                }
        });

        //set up the ListView item click listener for deleting
        listView.setOnItemClickListener((parent, view1, position, id) -> {

            //delete location from the database
            boolean success = databaseHelper.deleteLocation(id);
            if (success)
                {
                    Toast.makeText(getContext(), "Location deleted", Toast.LENGTH_SHORT).show();
                    refreshList();
                }
            else
                {
                    Toast.makeText(getContext(), "could not delete location", Toast.LENGTH_SHORT).show();
                }
        });

        //for searching through locations
        addressInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                filterAddress(s.toString());
            }
        });
        //call method for inserting locations
        load_data();
    }

    //method for filtering search results
    private void filterAddress(String text) {
        Cursor newCursor = databaseHelper.getMatchingLocations(text);
        adapter.changeCursor(newCursor);
        adapter.notifyDataSetChanged();
    }

    //loading data into array
    private void load_data() {
        new Thread(() -> {
            try {
                //open json file
                InputStream input = getActivity().getAssets().open("locations.json");
                int size = input.available();
                byte[] buffer = new byte[size];
                input.read(buffer);
                input.close();

                //convert the buffer to a string
                String json = new String(buffer, "UTF-8");

                //parse the JSON string
                JSONArray jsonArray = new JSONArray(json);

                //json array to work with
                geocodeAndStoreLocations(jsonArray);

            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        }).start();
    }

    //using the geocode class
    private void geocodeAndStoreLocations(JSONArray locationsJsonArray) {

        //call geocoder class
        Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

        //go through the json array
        for (int i = 0; i < locationsJsonArray.length(); i++) {

            try {
                //declare json object
                JSONObject obj = locationsJsonArray.getJSONObject(i);

                //set lat and long variables
                double latitude = obj.getDouble("latitude");
                double longitude = obj.getDouble("longitude");

                //check if the latitude and longitude are viable
                if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)
                {
                    //skip item
                    continue;
                }

                //create list of adresses
                List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);

                //add location to list
                if (addresses != null && !addresses.isEmpty())
                    {
                        //create variable for location and add to list
                        String address = addresses.get(0).getAddressLine(0);
                        databaseHelper.addLocation(address, latitude, longitude);
                        long id = databaseHelper.addLocation(address, latitude, longitude);
                    }

            } catch (IOException | JSONException e) {

            }
        }

        //refresh list view
        if (getActivity() != null) {
            getActivity().runOnUiThread(this::refreshList);
        }
    }

    private void refreshList() {
        //geting all locations from the database
        Cursor cursor = databaseHelper.getAllLocations();

        ///traversing the cursors
        if (cursor != null && cursor.moveToFirst()) {

            //defining the cursor columns
            String[] from = new String[]{
                    DatabaseHelper.key_location_address,
                    DatabaseHelper.key_location_lat,
                    DatabaseHelper.key_location_long
            };

            //defining the id's of the item list layout components
            int[] to = new int[]{R.id.textViewAddress, R.id.textViewLatitude, R.id.textViewLongitude};

            //check if its first time running the app
            if (adapter == null)
                {
                    //creating a new cursor
                    adapter = new SimpleCursorAdapter(getActivity(),R.layout.list_item,cursor,from,to,0);
                    listView.setAdapter(adapter);

                }
            else
                {
                    adapter.changeCursor(cursor);
                }
        }
    }


}
