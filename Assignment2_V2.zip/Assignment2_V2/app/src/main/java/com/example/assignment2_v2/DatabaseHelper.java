package com.example.assignment2_v2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;


public class DatabaseHelper extends SQLiteOpenHelper {

    //Database Info
    private static final String database_name = "locations.db";
    private static final int database_version = 3; //Updated version number

    //Table Names
    private static final String tablelocations = "locations";

    //Locations Table Columns
    public  static final String key_location_id = "_id";
    public  static final String key_location_address = "address";
    public  static final String key_location_lat = "latitude";
    public  static final String key_location_long = "longitude";

    public DatabaseHelper(Context context) {
        super(context, database_name, null, database_version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_LOCATIONS_TABLE = "CREATE TABLE " + tablelocations +
                "(" +
                key_location_id + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                key_location_address + " TEXT," +
                key_location_lat + " REAL," +
                key_location_long + " REAL" +
                ")";

        db.execSQL(CREATE_LOCATIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + tablelocations);
        //Create tables again
        onCreate(db);
    }

    //adding a location to the database
    public long addLocation(String address, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(key_location_address, address);
        values.put(key_location_lat, latitude);
        values.put(key_location_long, longitude);

        //check if location already exists
        Cursor cursor = db.query(tablelocations, new String[]{key_location_id},key_location_lat + "=?" + " AND " + key_location_long + "=?",
                new String[]{String.valueOf(latitude), String.valueOf(longitude)}, null, null, null);

        //initialize with -1 for error by default
        long id = -1;
        if (cursor != null && cursor.moveToFirst())
            {
                //if location exists
                id = cursor.getLong(cursor.getColumnIndex(key_location_id));
                cursor.close();
            }
        else
            {
                //if location does not exist, insert new one
                try {
                    id = db.insertOrThrow(tablelocations, null, values);
                } catch (Exception e) {}
            }
        db.close();
        return id;
    }

    //method for searching locations
    public Cursor getMatchingLocations(String filter) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + tablelocations + " WHERE " + key_location_address + " LIKE ?";
        return db.rawQuery(query, new String[]{"%" + filter + "%"});
    }

    //method for deleting location
    public boolean deleteLocation(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleteCount = db.delete(tablelocations, key_location_id + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return deleteCount > 0;
    }

    //method for displaying all locations
    public Cursor getAllLocations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + tablelocations, null);
    }

}
